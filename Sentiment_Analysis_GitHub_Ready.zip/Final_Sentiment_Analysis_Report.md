# Sentiment Analysis: A Comparative Study of Machine Learning Classifiers on Multi-Domain Consumer Reviews

---

**Author:** Archana Sivakumar

**Institution:** SRM Institute of Science and Technology

**Course:** Machine Learning / Natural Language Processing

**Date:** October 2026

---

---

## Table of Contents

1. [Abstract](#1-abstract)
2. [Introduction](#2-introduction)
3. [Problem Statement](#3-problem-statement)
4. [Objectives](#4-objectives)
5. [Dataset Description](#5-dataset-description)
6. [Data Preprocessing](#6-data-preprocessing)
7. [TF-IDF Feature Extraction](#7-tf-idf-feature-extraction)
8. [Proposed System Architecture](#8-proposed-system-architecture)
9. [Implementation: Naïve Bayes](#9-implementation-naïve-bayes)
10. [Implementation: Decision Tree](#10-implementation-decision-tree)
11. [Implementation: KNN](#11-implementation-knn)
12. [Implementation: SVM](#12-implementation-svm)
13. [Experimental Setup](#13-experimental-setup)
14. [Results: Metric Comparison Table](#14-results-metric-comparison-table)
15. [Model Performance Graph](#15-model-performance-graph)
16. [Confusion Matrix Analysis](#16-confusion-matrix-analysis)
17. [What-If Experiment](#17-what-if-experiment)
18. [Best Model Selection](#18-best-model-selection)
19. [Applications and Limitations](#19-applications-and-limitations)
20. [Conclusion and Future Scope](#20-conclusion-and-future-scope)
21. [References](#21-references)

---

## 1. Abstract

This study presents a systematic comparative analysis of four classical machine learning classifiers — Multinomial Naïve Bayes, Decision Tree, K-Nearest Neighbours (KNN), and Support Vector Machine (SVM) — applied to the task of binary sentiment classification on short consumer review texts. The experimental corpus is derived from the UCI Sentiment Labelled Sentences dataset (Kotzias et al., 2015), comprising 3,000 sentences drawn from three distinct domains: Amazon product reviews, IMDb film reviews, and Yelp service reviews. Following a rigorous preprocessing pipeline that included lowercasing, noise removal with selective apostrophe preservation for negation handling, and pre-split deduplication to prevent data leakage, 2,971 clean records were retained. Feature representation was achieved via Term Frequency–Inverse Document Frequency (TF-IDF) vectorisation using unigrams and bigrams, fitted exclusively on the training partition. All four classifiers were evaluated under identical experimental conditions using a stratified 80/20 train-test split. Results demonstrate that Linear SVM achieved the highest performance across all primary metrics, attaining an accuracy of 81.01%, precision of 81.29%, recall of 80.47%, and an F1-score of 0.8088. A what-if sensitivity experiment varying the SVM regularisation parameter C further confirmed that C = 1.0 yields the optimal trade-off between margin width and classification error. These findings establish SVM as the most suitable baseline classifier for short-text binary sentiment analysis under the constraints of this experimental design.

---

## 2. Introduction

Sentiment analysis, also referred to as opinion mining, is a subfield of Natural Language Processing (NLP) that focuses on computationally identifying and categorising the subjective opinions, attitudes, and emotions expressed in textual data. With the exponential growth of user-generated content across digital platforms — including e-commerce portals, social media networks, and online review aggregators — the ability to automatically infer sentiment polarity from text has become an increasingly critical capability for both academic research and commercial deployment. Binary sentiment classification, wherein text is assigned either a positive or negative polarity label, represents the foundational formulation of this problem and continues to serve as a benchmark task for evaluating natural language understanding systems ranging from traditional machine learning models to modern transformer-based architectures.

The comparative evaluation of classical machine learning classifiers for text classification tasks retains strong relevance in the era of deep learning, particularly given considerations of computational cost, interpretability, and deployment constraints in resource-limited environments. While large pre-trained language models such as BERT and GPT achieve state-of-the-art performance on NLP benchmarks, their adoption is often impractical for scenarios requiring lightweight inference, transparent decision logic, or training from scratch on modest hardware. Understanding the relative strengths and weaknesses of established classifiers — Naïve Bayes, Decision Trees, KNN, and SVM — across standardised experimental conditions offers actionable guidance for practitioners who must select appropriate models for real-world sentiment analysis pipelines. This study contributes to that body of knowledge through a controlled, reproducible experimental framework applied to a well-known multi-domain benchmark dataset.

---

## 3. Problem Statement

The core problem addressed by this study is the principled comparison of four widely used supervised machine learning classifiers — Multinomial Naïve Bayes, Decision Tree, K-Nearest Neighbours, and Support Vector Machine — under strictly identical experimental conditions for the task of binary sentiment classification on short consumer review texts. The central challenge lies in determining which classifier best handles the linguistic characteristics of such texts, which are typically brief (often one to three sentences), domain-heterogeneous (spanning product, film, and service reviews), and rich in informal constructions, negation, and domain-specific vocabulary. By controlling all aspects of the experimental pipeline — data sourcing, preprocessing, feature extraction, train-test partitioning, and evaluation metrics — this study isolates classifier-specific behaviour as the sole explanatory variable for observed differences in predictive performance, thereby enabling a fair and reproducible comparative assessment.

---

## 4. Objectives

The following objectives guide the design and execution of this comparative study:

**Objective 1.** To construct a reproducible, contamination-free preprocessing and feature extraction pipeline for multi-domain short-text sentiment data, incorporating deduplication prior to train-test splitting to eliminate the risk of data leakage.

**Objective 2.** To implement and configure four supervised machine learning classifiers — Multinomial Naïve Bayes, Decision Tree, K-Nearest Neighbours, and Linear SVM — using well-justified hyperparameter settings appropriate for TF-IDF-transformed sparse text feature representations.

**Objective 3.** To rigorously evaluate all four classifiers on a held-out stratified test set using a consistent set of performance metrics, namely accuracy, precision, recall, and F1-score, with positive sentiment (label = 1) designated as the target class.

**Objective 4.** To conduct a sensitivity analysis (what-if experiment) on the SVM regularisation parameter C across a logarithmically spaced range of values, in order to characterise the model's response to the bias-variance trade-off and identify the optimal regularisation setting.

**Objective 5.** To synthesise the experimental findings into evidence-based recommendations regarding classifier selection for binary sentiment analysis tasks involving short consumer review texts, and to identify avenues for future enhancement through advanced representation learning and deep contextual modelling.

---

## 5. Dataset Description

The dataset employed in this study is the UCI Sentiment Labelled Sentences dataset, originally introduced by Kotzias, Denil, de Freitas, and Smyth (2015) in their work on learning individual labels from group-level annotations using deep features. The dataset is publicly available through the UCI Machine Learning Repository (DOI: 10.24432/C57604) and has since become a standard benchmark for binary sentiment classification research. It comprises 3,000 sentences equally distributed across three consumer review domains: Amazon product reviews, IMDb movie reviews, and Yelp restaurant and service reviews, with 1,000 sentences drawn from each source. Each sentence is accompanied by a binary sentiment label (0 for negative, 1 for positive), and each domain subset is perfectly balanced with exactly 500 negative and 500 positive examples.

The data is stored in tab-separated text files (`amazon_cells_labelled.txt`, `imdb_labelled.txt`, `yelp_labelled.txt`), with each line containing a raw review sentence followed by its integer label. The sentences represent authentic user-generated content and exhibit the characteristic brevity, informality, and domain-specific vocabulary of online consumer reviews, making the dataset particularly challenging for models reliant on syntactic regularity. The multi-domain composition of the corpus provides an additional layer of difficulty, as a classifier must generalise across divergent writing styles and vocabulary distributions. The full citation for this dataset is: Kotzias, D., Denil, M., de Freitas, N., & Smyth, P. (2015). From group to individual labels using deep features. In *Proceedings of the 21st ACM SIGKDD International Conference on Knowledge Discovery and Data Mining* (pp. 597–606). ACM.

---

## 6. Data Preprocessing

Raw text data sourced from consumer review platforms invariably contains noise in the form of punctuation artefacts, hyperlinks, inconsistent casing, and duplicate entries, all of which can distort the feature space and lead to misleading classifier performance estimates. A multi-stage preprocessing pipeline was therefore applied to the merged 3,000-sentence corpus before any modelling steps were undertaken.

The first stage involved conversion of all text to lowercase, ensuring that lexically identical tokens differing only in capitalisation (e.g., "Good" and "good") are treated as a single feature. In the second stage, all URLs beginning with `http`, `https`, or `www` were stripped using regular expression matching, as such tokens carry no sentiment signal. The third stage removed all non-alphabetic characters with the explicit exception of apostrophes, which were deliberately preserved to maintain negation contractions such as "don't", "wasn't", and "can't". This distinction is linguistically motivated: the token "don't" encodes a semantic negation that, if collapsed to "dont" or split into "do" and "t", would lose its contrastive meaning and potentially misclassify otherwise negative statements as positive. Consecutive whitespace characters introduced by character removal were subsequently collapsed to single spaces and leading/trailing whitespace was stripped.

Following text normalisation, duplicate records were identified and removed based on the cleaned text string. Crucially, this deduplication step was performed on the full corpus *prior* to the train-test split. Deduplicating after splitting risks a scenario in which the same cleaned text appears in both partitions, artificially inflating test-set performance estimates — a form of data leakage. Applying deduplication beforehand eliminates this risk and ensures the integrity of the evaluation. The table below summarises the effect of preprocessing on corpus size.

| Stage | Records |
|---|---|
| Raw merged corpus | 3,000 |
| After removing empty text rows | 2,998 |
| After removing duplicate cleaned texts (27 removed) | 2,971 |
| **Final corpus used for modelling** | **2,971** |

The post-deduplication corpus of 2,971 records exhibits near-perfect class balance, with 1,486 negative (label = 0) and 1,485 positive (label = 1) examples. The source distribution after deduplication is 983 records from Amazon, 994 from IMDb, and 994 from Yelp, reflecting the minor reduction in each domain subset attributable to removed duplicates.

---

## 7. TF-IDF Feature Extraction

Term Frequency–Inverse Document Frequency (TF-IDF) is a classical information retrieval weighting scheme that produces a numerical representation of text by measuring how frequently a term appears in a given document relative to how commonly it appears across the entire document collection (Salton & Buckley, 1988). Intuitively, terms that appear frequently in a specific document but rarely across the corpus are assigned high weights, as they are considered more discriminative. Conversely, terms that appear with high frequency across almost all documents (e.g., "the", "is") receive near-zero weights, effectively acting as stop words without requiring an explicit removal step.

Formally, the TF-IDF weight for term $t$ in document $d$ within a corpus $D$ is given by:

$$\text{TF-IDF}(t, d, D) = \text{TF}(t, d) \times \text{IDF}(t, D)$$

where the Inverse Document Frequency is computed as:

$$\text{IDF}(t, D) = \log\left(\frac{1 + |D|}{1 + |\{d \in D : t \in d\}|}\right) + 1$$

In this study, `TfidfVectorizer` from scikit-learn was configured with `max_features=3000`, `ngram_range=(1,2)`, and `sublinear_tf=True`. The `ngram_range=(1,2)` setting instructs the vectoriser to consider both individual words (unigrams) and consecutive two-word sequences (bigrams), enabling the model to capture local phrase-level patterns such as "not good" or "highly recommend" that carry distinct sentiment signals beyond their constituent unigrams. Setting `max_features=3000` restricts the vocabulary to the 3,000 most informative terms by TF-IDF score, controlling the dimensionality of the feature space and mitigating the curse of dimensionality. The `sublinear_tf=True` setting applies a logarithmic transformation to raw term frequencies (replacing $\text{tf}$ with $1 + \log(\text{tf})$), compressing the dynamic range of count-based features so that a word appearing ten times in a document does not receive a weight ten times greater than one appearing once.

A critical methodological consideration is that the vectoriser was fitted exclusively on the training partition (2,376 records) and subsequently applied to the test set (595 records) via `transform` only. Fitting on the combined dataset would introduce vocabulary and IDF statistics derived from test-set documents into the feature space, constituting an information leak that would optimistically bias test-set performance estimates. By restricting fitting to the training data, the experimental setup faithfully simulates the deployment scenario in which the model has no prior knowledge of unseen documents.

---

## 8. Proposed System Architecture

The end-to-end pipeline implemented in this study follows a sequential, modular architecture as depicted below:

```
+-------------------+
|   Raw Dataset     |  (amazon_cells_labelled.txt,
|   (3 files)       |   imdb_labelled.txt, yelp_labelled.txt)
+--------+----------+
         |
         v
+--------+----------+
|  Load & Merge     |  (Concatenate into single DataFrame, assign source labels)
+--------+----------+
         |
         v
+--------+----------+
|  Inspect & EDA    |  (Check shape, class balance, null values, source distribution)
+--------+----------+
         |
         v
+--------+----------+
|   Preprocess      |  (Lowercase → Strip URLs → Remove non-alpha except apostrophes
|                   |   → Collapse whitespace)
+--------+----------+
         |
         v
+--------+----------+
|   Deduplicate     |  (Remove exact duplicates on cleaned text; 2,971 records retained)
+--------+----------+
         |
         v
+--------+----------+
| Stratified Split  |  (80% Train: 2,376 | 20% Test: 595 | random_state=42)
+--------+----------+
         |
         v
+--------+----------+
|  TF-IDF Vectorize |  (Fit on X_train only; transform X_train and X_test)
|  max_features=3000|  (ngram_range=(1,2), sublinear_tf=True)
+--------+----------+
         |
         v
+--------+-----------+-----------+-----------+
|  Naïve Bayes  | Decision  |    KNN    |    SVM    |
| (alpha=1.0)   |   Tree    | (k=5,cos) | (C=1.0,   |
|               |(depth=30) |           |  linear)  |
+--------+-----------+-----------+-----------+
         |
         v
+--------+----------+
|    Evaluate       |  (Accuracy, Precision, Recall, F1 on 595 test records)
+--------+----------+
         |
         v
+--------+----------+
| Cross-Model       |  (Comparison table, bar chart, confusion matrices)
| Comparison        |
+--------+----------+
         |
         v
+--------+----------+
|  Best Model       |  → SVM (F1 = 0.8088, Accuracy = 81.01%)
|  Selection        |
+--------+----------+
         |
         v
+--------+----------+
| Real-time         |  (Predict sentiment of new user-input text)
| Prediction        |
+-------------------+
```

---

## 9. Implementation: Naïve Bayes

Multinomial Naïve Bayes is a probabilistic generative classifier grounded in Bayes' theorem, which states that the posterior probability of a class $C$ given an observed feature vector $\mathbf{x}$ is proportional to the product of the class prior and the likelihood of the features given the class:

$$P(C \mid \mathbf{x}) \propto P(C) \cdot \prod_{i=1}^{n} P(x_i \mid C)$$

The "naïve" designation refers to the conditional independence assumption: the model assumes that each feature (i.e., each term in the vocabulary) contributes independently to the posterior probability of the class, given that class label. While this assumption is demonstrably violated in natural language — where words exhibit strong statistical dependencies — the model nevertheless performs remarkably well in practice for text classification tasks, a phenomenon attributed to the fact that exact probability estimates are less important than the correct ranking of class posteriors (Manning, Raghavan, & Schütze, 2008).

In the Multinomial variant, the likelihood $P(x_i \mid C)$ models the frequency of term $x_i$ in documents of class $C$. To prevent zero-probability estimates for terms absent from the training vocabulary of a particular class (which would nullify the entire product), Laplace smoothing with parameter $\alpha = 1.0$ is applied, adding a pseudocount of one to all term frequencies. This study configured `MultinomialNB(alpha=1.0)`, the scikit-learn default, which provides a reasonable balance between smoothing and fidelity to observed frequency distributions. Naïve Bayes is particularly well-suited to TF-IDF feature representations because the weighted term scores serve as approximate proxies for term importance, and the model's linear decision boundary in log-probability space aligns naturally with the sparse, high-dimensional structure of TF-IDF matrices.

---

## 10. Implementation: Decision Tree

A Decision Tree classifier partitions the feature space through a series of recursive binary splits, selecting at each internal node the feature and threshold that maximise the homogeneity of the resulting child partitions. In this study, split quality is measured using the Gini impurity criterion, defined for a node containing samples from $K$ classes as:

$$\text{Gini} = 1 - \sum_{k=1}^{K} p_k^2$$

where $p_k$ is the proportion of samples belonging to class $k$ in the node. A Gini impurity of zero indicates a pure node containing samples from only one class, which represents the ideal terminal leaf condition. The algorithm greedily selects splits that maximise the weighted reduction in Gini impurity across the resulting child nodes, a quantity known as information gain.

In the context of TF-IDF feature spaces, Decision Trees face an inherent scalability challenge. With 3,000 features in the vocabulary, the tree must evaluate all possible splits across all features at every node, and without depth restriction the resulting tree may grow to accommodate essentially every training example — producing high variance and severe overfitting. The `max_depth=30` constraint applied in this study limits tree growth to 30 levels, providing a practical upper bound on model complexity while still permitting the tree to explore a substantial portion of the feature space. Even with this constraint, the Decision Tree recorded the lowest F1-score among the four classifiers, reflecting the fundamental tension between the greedy, axis-aligned split strategy of tree-based models and the high-dimensional, diffuse structure of text feature spaces.

---

## 11. Implementation: KNN

The K-Nearest Neighbours algorithm is a non-parametric, instance-based classifier that assigns a class label to a query instance by identifying the $k$ most similar instances in the training set and returning the majority class vote among those neighbours. In this study, `KNeighborsClassifier(n_neighbors=5, metric='cosine', algorithm='brute')` was employed. The cosine similarity metric was selected in preference to the Euclidean distance commonly used for dense feature spaces because cosine similarity measures the angular difference between two vectors rather than their absolute magnitude. In TF-IDF space, two documents with similar vocabulary and relative term importance will have a high cosine similarity regardless of their absolute term-frequency counts, making it a more appropriate distance measure for sparse text representations.

Despite its conceptual elegance, KNN is susceptible to the curse of dimensionality in high-dimensional spaces: as the number of features increases, the notion of "nearness" becomes increasingly unreliable because all pairwise distances tend to converge, making it difficult to discriminate between genuinely similar and dissimilar documents. With 3,000 TF-IDF dimensions in the feature space, this phenomenon is evident in the KNN classifier's comparatively lower performance (F1 = 0.7621) relative to SVM and Naïve Bayes, despite the cosine metric partially mitigating this effect. Additionally, the `algorithm='brute'` setting, which computes exact pairwise cosine similarities across the entire training set for each query, is computationally intensive and does not scale readily to large corpora.

---

## 12. Implementation: SVM

Support Vector Machine classification is predicated on the principle of maximum margin separation: the algorithm seeks to identify a decision hyperplane in the feature space that separates the two classes with the largest possible margin, defined as the perpendicular distance between the hyperplane and the nearest training examples of each class (the support vectors). By maximising this margin, the classifier minimises its generalisation error under the structural risk minimisation framework, providing strong theoretical guarantees on out-of-sample performance even in high-dimensional settings (Manning et al., 2008).

`LinearSVC(C=1.0, random_state=42, max_iter=10000)` was employed in this study. The linear kernel is particularly well-suited to text classification because TF-IDF feature spaces, despite their high dimensionality (3,000 features in this study), are inherently linearly separable to a high degree — a consequence of the sparse, bag-of-words structure of the representation, where the presence or absence of specific discriminative terms is often sufficient to separate classes without recourse to non-linear transformations. The regularisation parameter C controls the trade-off between maximising the margin and minimising training-set classification errors: a smaller C enforces a wider margin at the cost of more misclassifications, while a larger C permits a narrower margin in pursuit of zero training error. At C = 1.0, the model achieves the optimal balance for this dataset, as confirmed by the what-if experiment described in Section 17.

---

## 13. Experimental Setup

All experiments were conducted using Python 3.11 with the following principal libraries: scikit-learn 1.9.1 for machine learning model implementations and evaluation utilities, pandas 3.1.0 for data ingestion and manipulation, and matplotlib 3.11.2 for visualisation. The experimental environment ensures full reproducibility through explicit setting of `random_state=42` wherever stochastic processes are involved.

The train-test split was performed using scikit-learn's `train_test_split` function with `test_size=0.20` and `stratify=label`, yielding 2,376 training records and 595 test records. Stratified splitting ensures that the class distribution of the original corpus (approximately 50/50) is preserved in both partitions, preventing scenarios in which random sampling produces unbalanced subsets that could artificially inflate or deflate minority-class performance metrics.

Model performance was quantified using four metrics, each computed with `pos_label=1` (positive sentiment designated as the target class): **Accuracy** measures the overall proportion of correctly classified instances. **Precision** measures the proportion of instances predicted as positive that are truly positive, capturing the classifier's false positive rate. **Recall** measures the proportion of true positive instances that are correctly identified, capturing the classifier's sensitivity. **F1-score** is the harmonic mean of precision and recall, providing a balanced single-figure summary of discriminative performance. Cross-algorithm fairness is ensured by the application of an identical preprocessing pipeline, feature extraction vocabulary, train-test split, and evaluation protocol to all four classifiers, so that observed performance differences are attributable solely to classifier characteristics rather than experimental artefacts.

---

## 14. Results: Metric Comparison Table

The following table presents the test-set performance of all four classifiers on the 595 held-out records, ranked in descending order by F1-score. Linear SVM achieves the highest score on all four metrics, demonstrating consistent superiority over the remaining classifiers. Naïve Bayes ranks second with competitive performance, particularly notable given its simplicity. KNN ranks third, with performance meaningfully below the top two models. Decision Tree records the lowest performance across all metrics, indicating the most severe generalisation difficulty on this task.

| Rank | Model | Accuracy | Precision | Recall | F1-Score |
|---|---|---|---|---|---|
| 1 | **SVM (LinearSVC)** | **0.8101** | **0.8129** | **0.8047** | **0.8088** |
| 2 | Naïve Bayes | 0.7983 | 0.7980 | 0.7980 | 0.7980 |
| 3 | KNN (k=5, cosine) | 0.7597 | 0.7533 | 0.7710 | 0.7621 |
| 4 | Decision Tree (depth=30) | 0.7092 | 0.7246 | 0.6734 | 0.6981 |

*Note: All metrics computed on 595 test records (298 negative, 297 positive); pos_label=1.*

SVM surpasses Naïve Bayes by approximately 1.08 percentage points in accuracy and 1.08 points in F1-score. The gap between SVM and Decision Tree is considerably larger — approximately 10.07 percentage points in accuracy and 11.07 points in F1-score — underscoring the particular suitability of linear maximum-margin classifiers for sparse text feature spaces.

---

## 15. Model Performance Graph

Figure 1 presents a grouped bar chart illustrating the accuracy, precision, recall, and F1-score for all four classifiers, saved to `results/model_comparison.png`. Each classifier is represented by a cluster of four bars corresponding to the four evaluation metrics, facilitating direct visual comparison across both classifiers and metrics simultaneously. The chart makes immediately apparent the consistent ordering of classifiers across all metrics: SVM uniformly occupies the highest position, followed by Naïve Bayes, KNN, and Decision Tree in descending order. The relative uniformity of the four metric values within each classifier cluster (most notably for Naïve Bayes, where all four metrics converge at approximately 0.798) reflects the near-perfect class balance of the test set, which minimises divergence between accuracy and the precision-recall-based metrics. The Decision Tree exhibits the greatest within-cluster spread, with precision (0.7246) noticeably exceeding recall (0.6734), indicating a systematic bias toward false negatives — i.e., a tendency to misclassify positive reviews as negative.

---

## 16. Confusion Matrix Analysis

A confusion matrix decomposes classifier predictions into four categories: True Negatives (TN), False Positives (FP), False Negatives (FN), and True Positives (TP), providing a granular view of error distribution that aggregate metrics do not fully convey. The test set consists of 298 negative examples and 297 positive examples.

### Support Vector Machine

| | Predicted Negative | Predicted Positive |
|---|---|---|
| **Actual Negative** | TN = 243 | FP = 55 |
| **Actual Positive** | FN = 58 | TP = 239 |

The SVM misclassifies 113 of 595 test instances, yielding a misclassification rate of 18.99%. The near-symmetric distribution of errors (55 FP vs. 58 FN) indicates that the model does not exhibit a strong directional bias toward either false positives or false negatives, reflecting the balanced margin-maximisation objective of the SVM.

### Naïve Bayes

| | Predicted Negative | Predicted Positive |
|---|---|---|
| **Actual Negative** | TN = 238 | FP = 60 |
| **Actual Positive** | FN = 60 | TP = 237 |

Naïve Bayes misclassifies 120 instances, corresponding to a misclassification rate of 20.17%. The perfectly symmetric error distribution (60 FP and 60 FN) is a consequence of the model's calibrated probability estimates and the balanced class prior, and it results in equal precision and recall values (0.7980), which in turn makes the F1-score identical to both.

### K-Nearest Neighbours

| | Predicted Negative | Predicted Positive |
|---|---|---|
| **Actual Negative** | TN = 223 | FP = 75 |
| **Actual Positive** | FN = 68 | TP = 229 |

KNN misclassifies 143 instances, producing a misclassification rate of 24.03%. The asymmetry between FP (75) and FN (68) indicates a slight positive bias — the model predicts the positive class somewhat more liberally than justified. This is reflected in recall (0.7710) slightly exceeding precision (0.7533), suggesting the model is marginally more inclined to label ambiguous instances as positive.

### Decision Tree

| | Predicted Negative | Predicted Positive |
|---|---|---|
| **Actual Negative** | TN = 222 | FP = 76 |
| **Actual Positive** | FN = 97 | TP = 200 |

Decision Tree records the highest misclassification count at 173 instances (misclassification rate: 29.08%). The pronounced asymmetry between FN (97) and FP (76) indicates a strong negative bias — the classifier fails to identify a substantially larger number of true positive instances than it incorrectly labels negative instances as positive. This behaviour may be attributed to the tree's greedy split strategy causing early-stage branches to over-represent the dominant vocabulary of the negative class, suppressing recall for positive examples.

---

## 17. What-If Experiment

To investigate the sensitivity of the SVM classifier to the choice of regularisation parameter C, a controlled what-if experiment was conducted in which C was varied across five values spanning four orders of magnitude: {0.01, 0.10, 1.00, 10.00, 100.00}. All other experimental conditions — train-test split, preprocessing, TF-IDF vectorisation — were held constant. The results are reported in the table below and visualised in `results/what_if_svm_c.png`.

| C | Accuracy | Precision | Recall | F1-Score |
|---|---|---|---|---|
| 0.01 | 0.7647 | 0.7794 | 0.7374 | 0.7578 |
| 0.10 | 0.8000 | 0.8134 | 0.7778 | 0.7952 |
| **1.00** | **0.8101** | **0.8129** | **0.8047** | **0.8088** |
| 10.00 | 0.8050 | 0.8007 | 0.8114 | 0.8060 |
| 100.00 | 0.8017 | 0.7973 | 0.8081 | 0.8027 |

At C = 0.01, the model is heavily regularised and the resulting decision boundary is overly constrained, producing a wide margin that accommodates fewer support vectors but misclassifies a larger proportion of the training data. The comparatively low recall (0.7374) at this setting is consistent with underfitting: the classifier does not sufficiently adapt to the training distribution and thereby fails to correctly identify a substantial fraction of the positive test examples.

As C increases from 0.01 to 1.00, all four performance metrics improve monotonically, reflecting the progressive reduction of underfitting as the margin width is tightened to accommodate more of the training data's structure. The peak performance across all metrics is achieved at C = 1.00, confirming this as the optimal regularisation setting for the given feature space and dataset. Beyond C = 1.00, marginal performance declines slightly — accuracy falls from 0.8101 to 0.8050 at C = 10.0 and to 0.8017 at C = 100.0 — indicating the onset of mild overfitting: the classifier begins to prioritise minimising training errors over maximising generalisation margin, resulting in a boundary that is overly tuned to training-set noise. The experiment thus confirms that C = 1.00 represents the optimal bias-variance trade-off for Linear SVM on this task, and that performance is relatively stable in the neighbourhood of this value, declining only gradually for an order-of-magnitude deviation in either direction.

---

## 18. Best Model Selection

On the basis of the experimental results presented in Section 14, Linear SVM is identified as the best-performing classifier for binary sentiment classification on the UCI Sentiment Labelled Sentences corpus. SVM achieves the highest score on all four evaluation metrics simultaneously — accuracy (0.8101), precision (0.8129), recall (0.8047), and F1-score (0.8088) — leaving no ambiguity in its ranking relative to the competing classifiers.

The superior performance of SVM on this task is theoretically well-founded. TF-IDF feature vectors are sparse and high-dimensional, and this structural property is precisely the setting in which linear maximum-margin classifiers excel. Because each document is represented as a point in a 3,000-dimensional space with most coordinates equal to zero, the classes are likely to be linearly separable to a high degree, and the SVM's maximum-margin objective ensures that the decision boundary is placed as far from the nearest training examples as possible, providing strong resistance to minor perturbations in unseen data. Furthermore, the L2-regularised objective of LinearSVC implicitly performs feature selection by assigning large absolute weights to the most discriminative terms and near-zero weights to uninformative ones, effectively compressing the decision logic into a compact linear scoring function.

In comparison, Naïve Bayes performs competitively (F1 = 0.7980) despite its strong independence assumption, benefiting from the low-variance, high-bias characteristics that serve well in small-to-medium training set regimes. KNN (F1 = 0.7621) suffers from the curse of dimensionality inherent to the 3,000-dimensional TF-IDF space, and although the cosine metric partially compensates, the nearest-neighbour paradigm cannot match the global discriminative power of the SVM boundary. Decision Tree (F1 = 0.6981) is the most severely disadvantaged classifier in this setting: its greedy, axis-aligned splitting strategy is poorly adapted to the diffuse, correlated feature space of text data, and the max_depth=30 constraint, while preventing full overfit, does not resolve the fundamental mismatch between tree induction and high-dimensional sparse representations.

---

## 19. Applications and Limitations

The system and experimental methodology developed in this study have broad applicability across a range of real-world sentiment analysis scenarios. In e-commerce, the trained SVM classifier can be deployed as a backend component in automated product review monitoring systems that continuously ingest new customer feedback and flag negative sentiment for priority review by customer service teams. In social media analytics, similar pipelines can be applied to brand monitoring tasks, enabling organisations to track public sentiment toward products, campaigns, or events in near real-time. The binary classification framework is also directly applicable to financial sentiment analysis — for instance, classifying news headlines or analyst reports as expressing positive or negative outlooks — and to political opinion mining from public discourse platforms. The modular pipeline architecture, in which preprocessing, feature extraction, and classification are decoupled, facilitates rapid adaptation to new domains by retraining the TF-IDF vectoriser and SVM on domain-specific labelled data.

Nevertheless, several substantive limitations constrain the generalisability and practical scope of the current study. The classification task is restricted to binary polarity (positive vs. negative), which is insufficient for applications requiring finer-grained sentiment resolution, such as distinguishing strongly negative from mildly negative sentiment or identifying neutral expressions. The training corpus of 2,971 records, while adequate for a controlled comparative study, is modest in scale relative to the volumes of text typically encountered in production sentiment analysis systems, and the comparatively small training set may under-represent the full diversity of consumer language patterns. Domain shift presents a further concern: a classifier trained exclusively on Amazon, IMDb, and Yelp reviews may not generalise reliably to texts from other domains (e.g., Twitter, news commentary, or medical feedback forums) without retraining on domain-matched data. Finally, TF-IDF representation encodes no positional, syntactic, or long-range contextual information, rendering the model insensitive to constructions such as irony, sarcasm, and complex negation that depend on inter-sentence discourse structure — capabilities that are only beginning to be addressed through contextualised embeddings from pre-trained language models.

---

## 20. Conclusion and Future Scope

This study conducted a systematic comparative evaluation of four supervised machine learning classifiers — Multinomial Naïve Bayes, Decision Tree, K-Nearest Neighbours, and Linear Support Vector Machine — for binary sentiment classification on the UCI Sentiment Labelled Sentences dataset. Through a rigorously controlled experimental pipeline encompassing multi-stage text preprocessing with pre-split deduplication, TF-IDF feature extraction fitted exclusively on the training partition, and consistent stratified evaluation across all classifiers, the study produced reproducible and internally valid performance estimates. The principal finding is that Linear SVM achieves the highest performance across all four evaluation metrics, attaining an accuracy of 81.01% and an F1-score of 0.8088 on the 595-record held-out test set. The what-if sensitivity analysis confirmed that the regularisation parameter C = 1.0 represents the optimal setting, with measurable underfitting at C = 0.01 and marginal overfitting at C ≥ 10.0. These results are consistent with the broader literature on text classification, which repeatedly identifies linear SVMs as particularly well-suited to sparse, high-dimensional TF-IDF feature representations.

Several directions for future investigation are identified. The most impactful enhancement would be the replacement of TF-IDF with contextualised sentence embeddings derived from pre-trained transformer models such as BERT (Bidirectional Encoder Representations from Transformers) or RoBERTa, which encode rich syntactic and semantic context and have demonstrated substantial performance gains over bag-of-words representations on a wide range of NLP benchmarks. Extending the classification framework from binary polarity to multi-class sentiment — incorporating neutral, strongly positive, and strongly negative categories — would increase the practical utility of the system for nuanced opinion analysis. Integration with real-time data streaming infrastructure, such as Apache Kafka, would enable the pipeline to process high-velocity social media or review streams without batch latency. Finally, aspect-level sentiment analysis, which associates sentiment judgements with specific product or service attributes rather than the document as a whole, represents a richer and more actionable analytical objective that would substantially expand the applicability of the system to structured opinion summarisation tasks.

---

## 21. References

Kotzias, D., Denil, M., de Freitas, N., & Smyth, P. (2015). From group to individual labels using deep features. In *Proceedings of the 21st ACM SIGKDD International Conference on Knowledge Discovery and Data Mining* (pp. 597–606). ACM. https://doi.org/10.1145/2783258.2783380

Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to information retrieval*. Cambridge University Press. https://nlp.stanford.edu/IR-book/

Pedregosa, F., Varoquaux, G., Gramfort, A., Michel, V., Thirion, B., Grisel, O., Blondel, M., Prettenhofer, P., Weiss, R., Dubourg, V., Vanderplas, J., Passos, A., Cournapeau, D., Brucher, M., Perrot, M., & Duchesnay, É. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research*, *12*, 2825–2830.

Salton, G., & Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. *Information Processing & Management*, *24*(5), 513–523. https://doi.org/10.1016/0306-4573(88)90021-0

UCI Machine Learning Repository. (2015). *Sentiment labelled sentences data set* [Data set]. University of California, Irvine. https://doi.org/10.24432/C57604

---

*End of Report*
