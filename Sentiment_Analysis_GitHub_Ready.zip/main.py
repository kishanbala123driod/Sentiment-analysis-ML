"""Reproducible comparison for UCI Sentiment Labelled Sentences.
Usage:
  python main.py
  python main.py --predict 'A wonderful experience'
  python main.py --interactive
"""
from pathlib import Path
import argparse
import csv
import re
import sys
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
SOURCES = {
    'Amazon': 'amazon_cells_labelled.txt',
    'IMDb': 'imdb_labelled.txt',
    'Yelp': 'yelp_labelled.txt'
}


def clean(text):
    """Normalize text: lowercase, strip URLs, keep letters, spaces and apostrophes (preserves negation/contractions)."""
    text = str(text).lower()
    text = re.sub(r'https?://\S+|www\.\S+', ' ', text)
    text = re.sub(r"[^a-z\s']", ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def load_data():
    """Load, validate, inspect, and preprocess UCI Sentiment Labelled Sentences."""
    print("=" * 60)
    print("STEP 1: DATASET INTEGRATION & INSPECTION")
    print("=" * 60)
    dfs = []
    missing = []
    for source, name in SOURCES.items():
        path = DATA / name
        if not path.is_file():
            missing.append(name)
            continue
        # Use quoting=csv.QUOTE_NONE so unescaped quotes in review text don't corrupt line parsing
        frame = pd.read_csv(
            path,
            sep='\t',
            header=None,
            names=['text', 'label'],
            encoding='utf-8',
            quoting=csv.QUOTE_NONE,
            on_bad_lines='error'
        )
        frame['source'] = source
        print(f"Loaded {source:6s}: {len(frame)} records | Sentiment distribution: {frame['label'].value_counts().to_dict()}")
        dfs.append(frame)

    if missing:
        raise FileNotFoundError(
            'Missing files in data/: ' + ', '.join(missing) +
            '\nPlease place the 3 dataset files in the data/ directory. See README.md.'
        )

    df = pd.concat(dfs, ignore_index=True)
    df['text'] = df['text'].astype(str)
    df['label'] = pd.to_numeric(df['label'], errors='coerce')

    print(f"\nTotal combined raw records: {len(df)}")
    print(f"Combined label counts: {df['label'].value_counts().to_dict()} (0=Negative, 1=Positive)")
    print(f"Combined source counts: {df['source'].value_counts().to_dict()}")

    print("\nMissing values check:")
    print(df.isnull().sum().to_string())

    df = df.dropna(subset=['text', 'label']).copy()
    if not df['label'].isin([0, 1]).all():
        raise ValueError('Labels must be 0 (negative) or 1 (positive).')
    df['label'] = df['label'].astype(int)

    print("\n" + "=" * 60)
    print("STEP 2: PREPROCESSING & DEDUPLICATION")
    print("=" * 60)
    df['clean_text'] = df['text'].map(clean)
    non_empty_mask = df['clean_text'].str.len() > 0
    empty_removed = len(df) - non_empty_mask.sum()
    df = df[non_empty_mask].copy()

    n_before_dedup = len(df)
    # Deduplicate on normalized text so identical text cannot leak across train/test splits.
    conflict = df.groupby('clean_text')['label'].nunique()
    ambiguous = set(conflict[conflict > 1].index)
    if ambiguous:
        print(f"Found and removed {len(ambiguous)} ambiguous texts with conflicting labels across sources.")
        df = df[~df['clean_text'].isin(ambiguous)]

    exact_dupes_removed = df.duplicated('clean_text', keep='first').sum()
    df = df.drop_duplicates('clean_text', keep='first').reset_index(drop=True)
    total_removed = 3000 - len(df)

    print(f"Removed {empty_removed} empty cleaned text(s).")
    print(f"Removed {exact_dupes_removed} duplicate review texts.")
    print(f"Total records removed during cleaning: {total_removed}")
    print(f"Distinct records retained for modeling: {len(df)}")
    print(f"Class distribution after deduplication: {df['label'].value_counts().sort_index().to_dict()}")
    print(f"Source distribution after deduplication: {df['source'].value_counts().to_dict()}")
    return df


def get_models():
    """Define the 4 benchmark classifiers."""
    return {
        'Naive Bayes': MultinomialNB(alpha=1.0),
        'Decision Tree': DecisionTreeClassifier(max_depth=30, random_state=42),
        'KNN': KNeighborsClassifier(n_neighbors=5, metric='cosine', algorithm='brute'),
        'SVM': LinearSVC(C=1.0, random_state=42, max_iter=10000)
    }


def compute_metrics(y_true, y_pred):
    """Calculate actual Accuracy, Precision, Recall, and F1 (pos_label=1)."""
    return {
        'Accuracy': float(accuracy_score(y_true, y_pred)),
        'Precision': float(precision_score(y_true, y_pred, pos_label=1, zero_division=0)),
        'Recall': float(recall_score(y_true, y_pred, pos_label=1, zero_division=0)),
        'F1': float(f1_score(y_true, y_pred, pos_label=1, zero_division=0))
    }


def save_comparison_plot(df, out_path):
    """Plot and save performance comparison bar chart."""
    ax = df.set_index('Model')[['Accuracy', 'Precision', 'Recall', 'F1']].plot(
        kind='bar', figsize=(10, 6), ylim=(0, 1.05), rot=15, colormap='viridis'
    )
    ax.set_title('Sentiment Classification: Held-out Test Performance Comparison', fontsize=13, fontweight='bold')
    ax.set_ylabel('Score', fontsize=11)
    ax.set_xlabel('Model', fontsize=11)
    ax.legend(loc='lower right', frameon=True)
    ax.grid(axis='y', alpha=0.3, linestyle='--')
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.annotate(f"{height:.3f}", (p.get_x() + p.get_width() / 2., height),
                        ha='center', va='bottom', fontsize=8, rotation=90, xytext=(0, 3),
                        textcoords='offset points')
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def interactive_prediction(vect, fitted):
    """Interactive terminal prompt for real-time review sentiment prediction."""
    print("\n" + "=" * 60)
    print("REAL-TIME REVIEW SENTIMENT PREDICTOR")
    print("=" * 60)
    print("Type any review sentence to see predicted sentiment across all 4 models.")
    print("Type 'exit' or 'quit' to return to terminal.\n")
    while True:
        try:
            review = input("Enter review: ").strip()
            if not review:
                continue
            if review.lower() in ['exit', 'quit', 'q']:
                print("Exiting real-time prediction mode.")
                break
            clean_rev = clean(review)
            if not clean_rev:
                print("Please enter a sentence containing recognizable words.")
                continue
            item = vect.transform([clean_rev])
            print(f"\nPredictions for: \"{review}\"")
            for name, model in fitted.items():
                pred = model.predict(item)[0]
                label_str = "Positive" if pred == 1 else "Negative"
                print(f"  - {name:15s}: {label_str}")
            print("-" * 60)
        except (KeyboardInterrupt, EOFError):
            print("\nExiting real-time prediction mode.")
            break


def main():
    parser = argparse.ArgumentParser(description="Sentiment Analysis Comparative Study on UCI Dataset")
    parser.add_argument('--predict', type=str, help='Classify a specific review text')
    parser.add_argument('--interactive', action='store_true', help='Start interactive terminal review prediction')
    args = parser.parse_args()

    RESULTS.mkdir(exist_ok=True)
    df = load_data()

    print("\n" + "=" * 60)
    print("STEP 3: STRATIFIED SPLIT & TF-IDF VECTORIZATION")
    print("=" * 60)
    X_train, X_test, y_train, y_test = train_test_split(
        df['clean_text'],
        df['label'],
        test_size=0.20,
        stratify=df['label'],
        random_state=42
    )

    # Fit TF-IDF on training texts ONLY to avoid any test set leakage
    vect = TfidfVectorizer(max_features=3000, ngram_range=(1, 2), sublinear_tf=True)
    tr = vect.fit_transform(X_train)
    te = vect.transform(X_test)

    print(f"Training set records: {len(X_train)} (80%)")
    print(f"Testing set records:  {len(X_test)} (20%)")
    print(f"TF-IDF features:      {tr.shape[1]} (fitted on train only, max_features=3000, n-grams=(1,2))")

    print("\n" + "=" * 60)
    print("STEP 4: MODEL TRAINING & EVALUATION")
    print("=" * 60)
    results = []
    preds = pd.DataFrame({
        'original_text': df.loc[X_test.index, 'text'].to_numpy(),
        'source': df.loc[X_test.index, 'source'].to_numpy(),
        'actual_label': y_test.to_numpy(),
        'actual_sentiment': np.where(y_test.to_numpy() == 1, 'Positive', 'Negative')
    })
    fitted = {}

    for name, model in get_models().items():
        print(f"Training {name}...")
        model.fit(tr, y_train)
        p = model.predict(te)
        metrics = compute_metrics(y_test, p)
        results.append({'Model': name, **metrics})
        preds[f"pred_{name.lower().replace(' ', '_')}"] = p

        # Confusion Matrix
        cm = confusion_matrix(y_test, p, labels=[0, 1])
        disp = ConfusionMatrixDisplay(cm, display_labels=['Negative (0)', 'Positive (1)'])
        fig, ax = plt.subplots(figsize=(5.5, 4.5))
        disp.plot(cmap='Blues', values_format='d', ax=ax, colorbar=False)
        plt.title(f'{name} Confusion Matrix', fontsize=12, fontweight='bold')
        plt.tight_layout()

        # Save with standard and prefixed filenames
        stem = name.lower().replace(' ', '_')
        plt.savefig(RESULTS / f"confusion_{stem}.png", dpi=180)
        plt.savefig(RESULTS / f"confusion_matrix_{stem}.png", dpi=180)
        plt.close()

        fitted[name] = model

    comparison = pd.DataFrame(results).sort_values('F1', ascending=False)
    comparison.to_csv(RESULTS / 'model_comparison.csv', index=False, float_format='%.6f')
    preds.to_csv(RESULTS / 'test_predictions.csv', index=False)
    save_comparison_plot(comparison, RESULTS / 'model_comparison.png')

    print("\n" + "-" * 60)
    print("ACTUAL HELD-OUT TEST RESULTS (Positive class = 1):")
    print("-" * 60)
    print(comparison.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    print("-" * 60)
    print(f"Top performing model by F1-Score: {comparison.iloc[0]['Model']} (F1 = {comparison.iloc[0]['F1']:.4f})")

    print("\n" + "=" * 60)
    print("STEP 5: WHAT-IF EXPERIMENT (SVM Regularization Parameter C)")
    print("=" * 60)
    what_if = []
    c_values = [0.01, 0.1, 1.0, 10.0, 100.0]
    for c in c_values:
        clf = LinearSVC(C=c, random_state=42, max_iter=10000)
        clf.fit(tr, y_train)
        p = clf.predict(te)
        what_if.append({'SVM_C': c, **compute_metrics(y_test, p)})

    w = pd.DataFrame(what_if)
    w.to_csv(RESULTS / 'what_if_svm_c.csv', index=False, float_format='%.6f')

    fig, ax = plt.subplots(figsize=(8, 5))
    w.plot(x='SVM_C', y=['Accuracy', 'Precision', 'Recall', 'F1'], marker='o', logx=True, ylim=(0.70, 0.85), ax=ax)
    ax.set_title('What-If Study: SVM Regularization Parameter C vs Performance', fontsize=12, fontweight='bold')
    ax.set_ylabel('Score', fontsize=11)
    ax.set_xlabel('C parameter (Log scale)', fontsize=11)
    ax.grid(alpha=0.3, linestyle='--')
    plt.tight_layout()
    plt.savefig(RESULTS / 'what_if_svm_c.png', dpi=180)
    plt.close()

    print("What-If SVM C Results:")
    print(w.to_string(index=False, float_format=lambda x: f"{x:.4f}"))

    # Save complete experiment settings for auditability
    settings = {
        'dataset': 'UCI Sentiment Labelled Sentences (Amazon, IMDb, Yelp)',
        'records_raw': 3000,
        'records_retained': len(df),
        'cleaning': 'lowercase, strip URLs, retain letters, whitespace and apostrophes; drop duplicate & conflicting texts',
        'split': 'stratified 80/20 random_state=42',
        'tfidf': {
            'max_features': 3000,
            'ngram_range': [1, 2],
            'sublinear_tf': True,
            'fitted_on': 'X_train only'
        },
        'models': {
            'Naive Bayes': 'MultinomialNB(alpha=1.0)',
            'Decision Tree': 'DecisionTreeClassifier(max_depth=30, random_state=42)',
            'KNN': 'KNeighborsClassifier(n_neighbors=5, metric=cosine, algorithm=brute)',
            'SVM': 'LinearSVC(C=1.0, random_state=42, max_iter=10000)'
        },
        'what_if_c_values': c_values
    }
    (RESULTS / 'experiment_settings.json').write_text(json.dumps(settings, indent=2), encoding='utf-8')
    print(f"\nAll results, CSVs, and figures saved to: {RESULTS}")

    if args.predict:
        item = vect.transform([clean(args.predict)])
        print("\n" + "=" * 60)
        print(f"CUSTOM REVIEW PREDICTION: \"{args.predict}\"")
        print("=" * 60)
        for name, model in fitted.items():
            pred = model.predict(item)[0]
            label_str = "Positive" if pred == 1 else "Negative"
            print(f"  - {name:15s}: {label_str}")
        print("=" * 60)
    elif args.interactive:
        interactive_prediction(vect, fitted)
    else:
        print("\n" + "=" * 60)
        print("REAL-TIME REVIEW PREDICTION OPTIONS")
        print("=" * 60)
        print("To classify custom reviews interactively, run:")
        print("  python main.py --interactive")
        print("Or predict a single review sentence:")
        print('  python main.py --predict "The product exceeded all my expectations!"')
        print("=" * 60)


if __name__ == '__main__':
    try:
        main()
    except (FileNotFoundError, ValueError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
