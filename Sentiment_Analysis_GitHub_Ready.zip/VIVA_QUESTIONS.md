# Viva Voce Questions — Sentiment Analysis Comparative Study

> **Dataset:** UCI Sentiment Labelled Sentences (Amazon, IMDb, Yelp)
> **Classifiers:** Naïve Bayes · Decision Tree · KNN · SVM
> **Feature Extraction:** TF-IDF

---

**Q1. What is the UCI Sentiment Labelled Sentences dataset and why was it chosen?**

**Answer:** The UCI Sentiment Labelled Sentences dataset consists of 3,000 customer reviews drawn equally from three sources — Amazon, IMDb, and Yelp — each labelled as positive (1) or negative (0). It was chosen because it provides a balanced, real-world, multi-domain benchmark that is well-suited for binary sentiment classification tasks. Its diversity across three platforms helps evaluate how well classifiers generalise beyond a single domain. Being publicly available and manageable in size, it is also ideal for a comparative machine-learning study without requiring specialised hardware.

---

**Q2. Why were 29 records removed during preprocessing?**

**Answer:** Out of 3,000 raw records, 29 were removed to ensure data quality — 2 records were empty (blank text with no usable content) and 27 were exact duplicates. Retaining empty records would introduce noise and cause errors during feature extraction, while duplicate records could bias the model by over-representing certain patterns, leading to inflated evaluation metrics. After removal, 2,971 clean records were retained for all subsequent steps.

---

**Q3. What is the purpose of stratified train-test split and why was 80:20 used?**

**Answer:** A stratified train-test split ensures that the class distribution (positive vs. negative) in the original dataset is preserved proportionally in both the training and test sets. This prevents situations where one class is over- or under-represented in the test set, which would produce misleading evaluation metrics. An 80:20 ratio was chosen as a standard industry practice that provides sufficient training data (2,376 samples) for the models to learn, while keeping a meaningful test set (595 samples) for unbiased evaluation. `random_state=42` was used to ensure reproducibility.

---

**Q4. What is TF-IDF and how does it represent text numerically?**

**Answer:** TF-IDF stands for Term Frequency–Inverse Document Frequency. It converts raw text into a numerical matrix where each value reflects how important a word is to a particular document relative to the entire corpus. Term Frequency (TF) measures how often a term appears in a document, while Inverse Document Frequency (IDF) downweights terms that appear in many documents (e.g., "the", "is"), reducing their discriminative power. In this project, `max_features=3000`, `ngram_range=(1,2)`, and `sublinear_tf=True` were used, capturing both unigrams and bigrams while applying log-scaling to term frequencies.

---

**Q5. Why was TF-IDF fitted only on training data and not the full dataset?**

**Answer:** Fitting the TF-IDF vectorizer only on the training data prevents **data leakage** — a situation where information from the test set inadvertently influences the model. If TF-IDF were fitted on the full dataset, the IDF weights would be calculated using vocabulary and frequencies from test samples, giving the model an unfair advantage during evaluation. In real-world deployment, unseen data is never available during training, so fitting only on training data ensures that the evaluation accurately reflects how the model would perform on genuinely new text.

---

**Q6. What is Naïve Bayes and what is Laplace smoothing?**

**Answer:** Naïve Bayes is a probabilistic classifier based on Bayes' theorem that assumes all features (words) are conditionally independent given the class label — an assumption that is "naïve" but works well in practice for text classification. It calculates the probability of each class given a document and selects the class with the highest posterior probability. Laplace smoothing (additive smoothing, `alpha=1.0`) adds a small count to every feature frequency to avoid zero-probability estimates for words that appear in the test set but not in training data for a given class. Without it, a single unseen word would make the entire posterior probability zero.

---

**Q7. What is the Gini impurity used in the Decision Tree classifier?**

**Answer:** Gini impurity is a measure of how often a randomly chosen element from a set would be incorrectly classified if it were labelled according to the distribution of labels in the subset. A Gini value of 0 means the node is perfectly pure (all samples belong to one class), while a value of 0.5 indicates maximum impurity for a binary classification problem. The Decision Tree algorithm splits nodes by choosing the feature and threshold that most reduces Gini impurity, creating branches that progressively separate classes. In this project, `max_depth=30` was used, allowing relatively deep trees while preventing unlimited growth.

---

**Q8. Why does KNN underperform compared to SVM in this project?**

**Answer:** K-Nearest Neighbours (KNN) with k=5 and cosine similarity achieved an F1-score of 0.7621, the second-lowest among the four classifiers. KNN is a lazy, instance-based learner that makes predictions by finding the k most similar training samples at query time; it does not build an explicit decision boundary. In high-dimensional TF-IDF feature spaces (3,000 features), the "curse of dimensionality" makes distance/similarity measures less discriminative, as most points become equidistant. SVM, by contrast, is specifically designed to find an optimal separating hyperplane in high-dimensional spaces, making it inherently better suited for sparse text representations.

---

**Q9. What is Support Vector Machine and what is the regularization parameter C?**

**Answer:** A Support Vector Machine (SVM) is a discriminative classifier that finds the maximum-margin hyperplane separating two classes in a high-dimensional feature space. LinearSVC, used in this project, is an efficient linear SVM optimised for large sparse datasets like TF-IDF matrices. The regularization parameter **C** controls the trade-off between maximising the margin and minimising training misclassifications: a small C allows more margin violations (higher bias, lower variance), while a large C enforces strict classification (lower bias, higher variance). At C=1.0, the model achieved the best test F1-score of 0.8088.

---

**Q10. What is the difference between Precision and Recall, and why does F1-score matter?**

**Answer:** **Precision** measures the proportion of predicted positives that are truly positive (TP / (TP + FP)), reflecting how reliable the model's positive predictions are. **Recall** measures the proportion of actual positives correctly identified (TP / (TP + FN)), reflecting how well the model avoids missing true positives. In sentiment analysis, both matter: low precision means many false alarms, and low recall means missing genuine positive sentiments. The **F1-score** is the harmonic mean of precision and recall, providing a single balanced metric that penalises extreme imbalances between the two — making it more informative than accuracy alone, especially when class distributions or misclassification costs differ.

---

**Q11. How do you read a confusion matrix? Explain TN, FP, FN, TP using the SVM result.**

**Answer:** A confusion matrix is a 2×2 table that summarises the classification results by comparing predicted labels against actual labels. For the best-performing SVM on 595 test samples:
- **TN = 243**: Correctly predicted negative reviews (true negatives).
- **FP = 55**: Negative reviews incorrectly predicted as positive (false positives — Type I error).
- **FN = 58**: Positive reviews incorrectly predicted as negative (false negatives — Type II error).
- **TP = 239**: Correctly predicted positive reviews (true positives).

From these, Accuracy = (243+239)/595 ≈ 0.8101, Precision = 239/(239+55) ≈ 0.8129, and Recall = 239/(239+58) ≈ 0.8047.

---

**Q12. Why is SVM the best-performing classifier in this project?**

**Answer:** SVM (LinearSVC, C=1.0) achieved the highest scores across all metrics: Accuracy=0.8101, Precision=0.8129, Recall=0.8047, and F1=0.8088. SVMs excel in high-dimensional, sparse feature spaces — exactly the setting produced by TF-IDF vectorisation — because they directly optimise the classification margin rather than estimating probabilities. LinearSVC is also computationally efficient and robust to overfitting through its regularisation parameter C. The combination of a well-tuned C value, a linear kernel suited to linearly separable text data, and the inherent advantages of margin maximisation explains its superior performance over the other three classifiers.

---

**Q13. What did the what-if experiment on SVM's C parameter reveal?**

**Answer:** The what-if experiment systematically varied LinearSVC's regularisation parameter C across five values to observe its effect on test F1-score:

| C value | F1-score |
|---------|----------|
| 0.01 | 0.7578 |
| 0.1 | 0.7952 |
| **1.0** | **0.8088** ← Best |
| 10 | 0.8060 |
| 100 | 0.8027 |

The results reveal that C=1.0 is the sweet spot for this dataset — too small a C under-regularises the model (high bias), while too large a C overfits the training data (high variance). The performance plateaus and slightly degrades beyond C=1.0, confirming that the default value is well-calibrated for this TF-IDF + sentiment classification task.

---

**Q14. What are the main limitations of this comparative study?**

**Answer:** Several limitations affect the generalisability of this study. First, the dataset is relatively small (2,971 samples) and limited to three English-language domains, so findings may not transfer to other languages, domains, or larger corpora. Second, all classifiers use bag-of-words TF-IDF features, which ignore word order and contextual semantics, limiting their ability to handle sarcasm, negation, or complex sentence structures. Third, hyperparameter tuning was limited (e.g., only C was varied for SVM), so better configurations may exist. Finally, the binary labelling (positive/negative) does not capture nuanced sentiment intensities, and no ensemble or hybrid approaches were explored.

---

**Q15. How could this project be extended using deep learning or transformer models?**

**Answer:** The most impactful extension would be replacing TF-IDF with contextual word embeddings using pre-trained transformer models such as **BERT** (Bidirectional Encoder Representations from Transformers) or **RoBERTa**, which capture word meaning based on surrounding context and handle negation and sarcasm far more effectively. Fine-tuning BERT on the sentiment dataset would likely push accuracy well above 85–90%. Alternatively, simpler deep learning approaches such as LSTM or Bi-LSTM networks with GloVe or Word2Vec embeddings could capture sequential dependencies without the computational cost of full transformers. These extensions would also allow multi-class sentiment (e.g., positive, neutral, negative) and cross-lingual sentiment analysis using multilingual models like mBERT or XLM-R.

---

*End of Viva Questions*
