"""
prepare_submission.py
Run this script ONCE to create the classroom submission ZIP.
Usage: python prepare_submission.py
Output: Sentiment_Analysis_Submission.zip (created in the project root)
"""
from pathlib import Path
import zipfile
import datetime

ROOT = Path(__file__).resolve().parent
ZIP_NAME = "Sentiment_Analysis_Submission.zip"
ZIP_PATH = ROOT / ZIP_NAME

# Files and folders to INCLUDE
INCLUDE_FILES = [
    "main.py",
    "requirements.txt",
    "README.md",
    "OUTPUT.md",
    "Final_Sentiment_Analysis_Report.md",
    "VIVA_QUESTIONS.md",
]

INCLUDE_DIRS = {
    "data": ["amazon_cells_labelled.txt", "imdb_labelled.txt", "yelp_labelled.txt"],
    "results": [
        "model_comparison.csv",
        "model_comparison.png",
        "confusion_naive_bayes.png",
        "confusion_decision_tree.png",
        "confusion_knn.png",
        "confusion_svm.png",
        "test_predictions.csv",
        "what_if_svm_c.csv",
        "what_if_svm_c.png",
        "experiment_settings.json",
    ],
}

def create_zip():
    count = 0
    missing = []
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        # Root-level files
        for fname in INCLUDE_FILES:
            fpath = ROOT / fname
            if fpath.is_file():
                zf.write(fpath, fname)
                count += 1
                print(f"  [+] {fname}")
            else:
                missing.append(fname)
                print(f"  [!] MISSING: {fname}")

        # Subdirectory files
        for folder, files in INCLUDE_DIRS.items():
            for fname in files:
                fpath = ROOT / folder / fname
                if fpath.is_file():
                    arcname = f"{folder}/{fname}"
                    zf.write(fpath, arcname)
                    count += 1
                    print(f"  [+] {arcname}")
                else:
                    missing.append(f"{folder}/{fname}")
                    print(f"  [!] MISSING: {folder}/{fname}")

    print(f"\n{'='*55}")
    print(f"Submission ZIP created: {ZIP_PATH}")
    print(f"Files included: {count}")
    if missing:
        print(f"Files missing (not included): {len(missing)}")
        for m in missing:
            print(f"  - {m}")
    else:
        print("All expected files included successfully.")
    print(f"{'='*55}")

if __name__ == "__main__":
    print("Creating Sentiment Analysis submission ZIP...")
    print(f"Timestamp: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    create_zip()

