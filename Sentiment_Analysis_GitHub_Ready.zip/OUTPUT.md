# OUTPUT.md — Sentiment Analysis Comparative Study
### UCI Sentiment Labelled Sentences Dataset | Actual Experimental Results

> All scores, metrics, and confusion matrix values on this page are **actual computed results** obtained by executing `main.py` on the official UCI dataset. No values have been fabricated or estimated.

---

## 1. Dataset Information

| Property | Value |
| :--- | :--- |
| **Dataset Name** | UCI Sentiment Labelled Sentences (Kotzias et al., 2015) |
| **Official Source** | https://archive.ics.uci.edu/dataset/331/sentiment+labelled+sentences |
| **License** | Creative Commons Attribution 4.0 (CC BY 4.0) |
| **Citation DOI** | `10.24432/C57604` |
| **Sources Combined** | Amazon (product reviews), IMDb (movie reviews), Yelp (restaurant reviews) |
| **Format** | Tab-separated (`.txt`): `review_text \t sentiment_label` |
| **Labels** | `0` = Negative sentiment, `1` = Positive sentiment |

### Per-Source Record Counts (Raw)

| Source | Total Records | Negative (0) | Positive (1) |
| :--- | :---: | :---: | :---: |
| Amazon | 1,000 | 500 | 500 |
| IMDb | 1,000 | 500 | 500 |
| Yelp | 1,000 | 500 | 500 |
| **Combined Raw Total** | **3,000** | **1,500** | **1,500** |

### Missing Values Check (Raw Dataset)

| Column | Missing Values |
| :--- | :---: |
| `text` | 0 |
| `label` | 0 |
| `source` | 0 |

### Preprocessing & Deduplication Report

| Step | Count |
| :--- | :---: |
| Raw records loaded | 3,000 |
| Empty after cleaning (non-alpha-only, e.g. `10/10`) | 2 |
| Duplicate normalized review texts removed | 27 |
| **Total records removed** | **29** |
| **Distinct records retained for modeling** | **2,971** |

### Post-Cleaning Dataset Summary

| Property | Value |
| :--- | :---: |
| Total modeling records | 2,971 |
| Negative (0) | 1,486 |
| Positive (1) | 1,485 |
| Amazon records | 983 |
| IMDb records | 994 |
| Yelp records | 994 |

---

## 2. Train / Test Split & Feature Extraction

| Property | Value |
| :--- | :--- |
| **Split ratio** | 80% Training : 20% Testing |
| **Split type** | Stratified (preserves 50/50 class balance in both partitions) |
| **Random seed** | `random_state = 42` |
| **Training records** | 2,376 |
| **Testing records** | 595 |
| **Vectorizer** | `TfidfVectorizer(max_features=3000, ngram_range=(1,2), sublinear_tf=True)` |
| **TF-IDF fitted on** | Training set only (X_train) — prevents data leakage |
| **Feature dimensions** | 3,000 TF-IDF features (unigrams + bigrams) |

---

## 3. Model Evaluation Results

### Actual Held-Out Test Performance (595 test records, Positive class = 1)

| Rank | Model | Accuracy | Precision | Recall | F1-Score |
| :---: | :--- | :---: | :---: | :---: | :---: |
| 🥇 1 | **Support Vector Machine (SVM)** | **0.8101** | **0.8129** | **0.8047** | **0.8088** |
| 🥈 2 | Naïve Bayes | 0.7983 | 0.7980 | 0.7980 | 0.7980 |
| 🥉 3 | K-Nearest Neighbours (KNN) | 0.7597 | 0.7533 | 0.7710 | 0.7621 |
| 4 | Decision Tree | 0.7092 | 0.7246 | 0.6734 | 0.6981 |

> Source file: [`results/model_comparison.csv`](results/model_comparison.csv)

---

## 4. Model Comparison Chart

**File:** [`results/model_comparison.png`](results/model_comparison.png)

This bar chart displays Accuracy, Precision, Recall, and F1-Score for all four classifiers evaluated on the 595 held-out test samples. Values are annotated above each bar. The Y-axis ranges from 0 to 1.05.

---

## 5. Confusion Matrices

All confusion matrices follow the standard layout:
- **Rows:** Actual class (Negative row first, then Positive)
- **Columns:** Predicted class (Negative column first, then Positive)

### Test Set Composition
- Total test records: **595**
- Actual Negative (0): **298**
- Actual Positive (1): **297**

---

### 5a. Support Vector Machine (SVM)

**File:** [`results/confusion_svm.png`](results/confusion_svm.png)

| | Predicted Negative (0) | Predicted Positive (1) |
| :--- | :---: | :---: |
| **Actual Negative (0)** | **243** (TN) | 55 (FP) |
| **Actual Positive (1)** | 58 (FN) | **239** (TP) |

- Correctly classified: **482 / 595** (Accuracy: 81.01%)
- False negatives (missed positive): 58
- False positives (wrong positive alarm): 55

---

### 5b. Naïve Bayes

**File:** [`results/confusion_naive_bayes.png`](results/confusion_naive_bayes.png)

| | Predicted Negative (0) | Predicted Positive (1) |
| :--- | :---: | :---: |
| **Actual Negative (0)** | **238** (TN) | 60 (FP) |
| **Actual Positive (1)** | 60 (FN) | **237** (TP) |

- Correctly classified: **475 / 595** (Accuracy: 79.83%)
- Symmetric error distribution (FP = FN = 60) explains why Precision = Recall = 0.7980

---

### 5c. K-Nearest Neighbours (KNN)

**File:** [`results/confusion_knn.png`](results/confusion_knn.png)

| | Predicted Negative (0) | Predicted Positive (1) |
| :--- | :---: | :---: |
| **Actual Negative (0)** | **223** (TN) | 75 (FP) |
| **Actual Positive (1)** | 68 (FN) | **229** (TP) |

- Correctly classified: **452 / 595** (Accuracy: 75.97%)
- Higher FP count (75) indicates KNN is over-predicting positive sentiment

---

### 5d. Decision Tree

**File:** [`results/confusion_decision_tree.png`](results/confusion_decision_tree.png)

| | Predicted Negative (0) | Predicted Positive (1) |
| :--- | :---: | :---: |
| **Actual Negative (0)** | **222** (TN) | 76 (FP) |
| **Actual Positive (1)** | 97 (FN) | **200** (TP) |

- Correctly classified: **422 / 595** (Accuracy: 70.92%)
- Highest FN count (97) — worst recall among all models

---

## 6. What-If Experiment: SVM Regularization Parameter C

Held the train/test split and TF-IDF features constant; only varied the regularization parameter `C` of `LinearSVC`.

> Source file: [`results/what_if_svm_c.csv`](results/what_if_svm_c.csv)
> Graph file: [`results/what_if_svm_c.png`](results/what_if_svm_c.png)

| SVM C Value | Accuracy | Precision | Recall | F1-Score | Interpretation |
| :---: | :---: | :---: | :---: | :---: | :--- |
| 0.01 | 0.7647 | 0.7794 | 0.7374 | 0.7578 | Heavy regularisation — underfitting |
| 0.10 | 0.8000 | 0.8134 | 0.7778 | 0.7952 | Balanced — strong generalization |
| **1.00** | **0.8101** | **0.8129** | **0.8047** | **0.8088** | **Optimal — best F1** |
| 10.00 | 0.8050 | 0.8007 | 0.8114 | 0.8060 | Slight overfitting — still good |
| 100.00 | 0.8017 | 0.7973 | 0.8081 | 0.8027 | Over-penalization — minor F1 drop |

**Key observation:** F1 peaks at `C = 1.0`. Decreasing `C` causes underfitting (lower recall); increasing `C` beyond 1.0 begins minor overfitting. The default `C = 1.0` is the optimal regularization setting for this dataset.

---

## 7. Best Model Identification & Analysis

### Best Classifier: **Support Vector Machine (LinearSVC, C=1.0)**

| Metric | Value |
| :--- | :---: |
| Accuracy | **81.01%** |
| Precision | **0.8129** |
| Recall | **0.8047** |
| **F1-Score** | **0.8088** |

### Why SVM Performs Best

SVM is the strongest classifier for this task for the following reasons:

1. **High-dimensional sparse data:** TF-IDF with 3,000 features creates a high-dimensional, sparse vector space. Linear SVMs are mathematically designed to find the maximum-margin hyperplane in such spaces without suffering from the curse of dimensionality.
2. **Maximum-margin principle:** By maximizing the geometric margin between positive and negative sentiment vectors, SVM inherently minimizes generalization error — it is the only model here that does this explicitly.
3. **Balanced Precision and Recall:** With Precision = 0.8129 and Recall = 0.8047, SVM achieves near-symmetric accuracy in both predicting positive reviews correctly *and* capturing actual positive reviews — crucial for balanced classification tasks.

### Why Other Models Underperform

| Model | Root Cause of Underperformance |
| :--- | :--- |
| **Naïve Bayes** | Assumes complete conditional feature independence — a fundamentally incorrect assumption for human text. Adjacent words carry compound sentiment ("not good" ≠ "not" + "good"). Despite this flaw, the Laplace smoothing (α=1.0) makes it a remarkably competitive baseline (79.83%). |
| **KNN (k=5)** | Relies on cosine distance between sparse TF-IDF vectors. Nearest-neighbour lookups in 3,000-dimensional space suffer from the "empty space" phenomenon — all points appear equidistant in very high dimensions. |
| **Decision Tree** | Prone to overfitting despite `max_depth=30`. A single tree cannot generalize well across vocabulary from three distinct domains (products, films, restaurants). Highest FN count (97) of all models — weakest recall. |

### The Precision–Recall Trade-off Explained

- **Precision** answers: *"Of all the reviews I predicted as Positive, how many actually are Positive?"* A high-precision model avoids falsely labelling negative reviews as positive.
- **Recall** answers: *"Of all the actually Positive reviews, how many did I successfully identify?"* A high-recall model misses fewer genuinely positive reviews.
- **F1-Score** is the harmonic mean of Precision and Recall. It penalizes imbalanced performance between the two — a model that is good at one but bad at the other scores poorly on F1.
- For this balanced (50/50) dataset, **F1-Score is the right primary metric** because accuracy alone cannot distinguish between a model that misses positives vs. a model that falsely flags negatives.

---

## 8. Interactive Prediction Demo

The trained models support real-time terminal-based sentiment prediction in two modes.

### Mode A: Interactive Terminal (Continuous Input)

```powershell
.\.venv\Scripts\python.exe main.py --interactive
```

At the prompt, type any review and press Enter. All four models predict simultaneously. Type `exit` to quit.

**Example Session:**
```
Enter review: The food was absolutely delicious and service was great
  - Naive Bayes    : Positive
  - Decision Tree  : Positive
  - KNN            : Positive
  - SVM            : Positive
------------------------------------------------------------

Enter review: The product broke on day one, total waste of money
  - Naive Bayes    : Negative
  - Decision Tree  : Negative
  - KNN            : Negative
  - SVM            : Negative
------------------------------------------------------------

Enter review: exit
Exiting real-time prediction mode.
```

### Mode B: Single Review from Command Line

```powershell
.\.venv\Scripts\python.exe main.py --predict "Absolutely loved the experience, will come back again"
```
**Output:**
```
  - Naive Bayes    : Positive
  - Decision Tree  : Positive
  - KNN            : Positive
  - SVM            : Positive
```

```powershell
.\.venv\Scripts\python.exe main.py --predict "Completely disappointed. The product stopped working within two days"
```
**Output:**
```
  - Naive Bayes    : Negative
  - Decision Tree  : Negative
  - KNN            : Negative
  - SVM            : Negative
```

---

## 9. Output Files Reference

| File | Description |
| :--- | :--- |
| `results/model_comparison.csv` | Tabular Accuracy, Precision, Recall, F1 for all 4 models |
| `results/model_comparison.png` | Annotated grouped bar chart comparing all 4 classifiers |
| `results/confusion_naive_bayes.png` | Confusion matrix — Naïve Bayes |
| `results/confusion_decision_tree.png` | Confusion matrix — Decision Tree |
| `results/confusion_knn.png` | Confusion matrix — K-Nearest Neighbours |
| `results/confusion_svm.png` | Confusion matrix — Support Vector Machine |
| `results/test_predictions.csv` | Full audit: original text, source, actual label, all 4 predictions |
| `results/what_if_svm_c.csv` | SVM C parametric sensitivity results |
| `results/what_if_svm_c.png` | Log-scale line graph of SVM performance vs C |
| `results/experiment_settings.json` | Complete reproducibility configuration record |

---

## 10. Reproducing the Experiment (Complete Instructions)

### Step 1 — Place Dataset Files

Ensure the following files are inside the `data/` folder:
- `data/amazon_cells_labelled.txt`
- `data/imdb_labelled.txt`
- `data/yelp_labelled.txt`

These are obtained from the official UCI archive: https://archive.ics.uci.edu/dataset/331/sentiment+labelled+sentences

### Step 2 — Set Up Python Virtual Environment

#### Windows (PowerShell):
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

#### macOS / Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Step 3 — Run Full Comparative Study

```powershell
.\.venv\Scripts\python.exe main.py
```

This will:
1. Load and verify all three dataset files
2. Combine, inspect, and preprocess the data
3. Create stratified 80/20 train/test split
4. Fit TF-IDF vectorizer on training data only
5. Train and evaluate all 4 classifiers on the identical test set
6. Save all CSVs, PNG visualizations, and JSON settings to `results/`
7. Print formatted evaluation tables to the terminal

### Step 4 — Interactive Prediction Demo

```powershell
.\.venv\Scripts\python.exe main.py --interactive
```

Or single prediction:

```powershell
.\.venv\Scripts\python.exe main.py --predict "Your review text here"
```

---

## 11. Conclusion

This comparative study demonstrates that **Support Vector Machine (LinearSVC, C=1.0)** is the best-performing classifier for binary sentiment classification on short consumer review text from Amazon, IMDb, and Yelp.

The key findings are:
- **SVM achieves the highest F1-Score (0.8088)** and the best balance between Precision (0.8129) and Recall (0.8047).
- **Naïve Bayes is the strongest baseline** (F1: 0.7980), nearly matching SVM despite its feature independence assumption.
- **KNN (F1: 0.7621)** struggles in high-dimensional TF-IDF space due to the curse of dimensionality.
- **Decision Tree (F1: 0.6981)** is the weakest model, suffering from the highest false-negative count (97) — it misses positive reviews most frequently.
- The **What-If experiment confirms C=1.0 is the optimal regularization setting** for LinearSVC on this dataset.
- All models are evaluated under strictly identical, fair conditions (same data, same split, same TF-IDF vocabulary, same evaluation metrics).

---

*Generated by `main.py` | Dataset: UCI Sentiment Labelled Sentences, DOI: 10.24432/C57604 | Python 3.11 | scikit-learn 1.9*

