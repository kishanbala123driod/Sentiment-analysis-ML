# Sentiment Analysis: Comparative Study of Machine Learning Classifiers

> **Naïve Bayes · Decision Tree · KNN · Support Vector Machine**  
> UCI Sentiment Labelled Sentences Dataset (Amazon, IMDb, Yelp)  
> Python 3.11 · scikit-learn · TF-IDF · Stratified 80:20 Split

---

## Project Overview

This project implements a rigorous, fully reproducible comparative study of four classical machine learning classifiers for **binary sentiment classification** (Positive / Negative) on short consumer review texts. All four classifiers are trained and evaluated under strictly identical conditions — same dataset, same preprocessing, same TF-IDF vocabulary, and the same stratified 80:20 train-test split — ensuring a fair, unbiased comparison.

**Best classifier:** Support Vector Machine (LinearSVC, C=1.0) — F1-Score = **0.8088**  
**Repository:** [https://github.com/kishanbala123driod/Sentiment-analysis-ML](https://github.com/kishanbala123driod/Sentiment-analysis-ML)

---

## System Workflow

```
┌─────────────────────────────────────────────────────────────┐
│             UCI Sentiment Labelled Sentences                │
│    (Amazon: 1,000 | IMDb: 1,000 | Yelp: 1,000 reviews)      │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 1. Data Integration & Validation                            │
│    - Read tab-separated files without quote corruption      │
│    - 3,000 raw sentences; perfectly balanced (1,500/1,500)  │
│    - Check missing values (0 nulls found)                   │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. Preprocessing & Deduplication                            │
│    - Lowercasing & URL removal                              │
│    - Clean special characters; PRESERVE apostrophes (')     │
│      (retains negations: don't, wasn't, can't, didn't)      │
│    - Deduplicate normalized text before splitting           │
│    - 29 records removed (2 empty + 27 duplicates)           │
│    - 2,971 clean records retained (1,486 Neg / 1,485 Pos)   │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. Stratified Train-Test Split (80:20, random_state=42)     │
│    - Training set: 2,376 records                            │
│    - Testing set:    595 records (untouched hold-out)       │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. TF-IDF Feature Extraction                                │
│    - max_features=3,000, ngram_range=(1,2), sublinear_tf   │
│    - FITTED ON TRAINING SET ONLY (zero data leakage)        │
│    - Transformed onto held-out test set                     │
└──────────────────────────────┬──────────────────────────────┘
                               │
            ┌──────────────────┼──────────────────┐
            ▼                  ▼                  ▼                  ▼
     ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
     │ Naïve Bayes │    │Decision Tree│    │     KNN     │    │     SVM     │
     │MultinomialNB│    │ max_depth=30│    │ k=5, cosine │    │LinearSVC C=1│
     └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    └──────┬──────┘
            └──────────────────┼──────────────────┘                  │
                               ▼                                     ▼
┌─────────────────────────────────────────────────────────────┐ ┌───────────┐
│ 5. Model Evaluation (on 595 held-out test samples)          │ │6. What-If │
│    - Accuracy, Precision, Recall, F1 (pos_label=1)          │ │Experiment │
│    - Four Confusion Matrices & Prediction Audit Log         │ │SVM C sweep│
│    - Model Comparison Bar Chart                             │ │[0.01..100]│
└──────────────────────────────┬──────────────────────────────┘ └─────┬─────┘
                               │                                     │
                               ▼                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│ 7. Real-Time Terminal Prediction (Interactive CLI / Single Sentence)      │
└───────────────────────────────────────────────────────────────────────────┘
```

---

## Dataset

| Property | Details |
|:---|:---|
| **Name** | UCI Sentiment Labelled Sentences |
| **Authors** | Kotzias, Denil, de Freitas & Smyth (2015) |
| **DOI** | [10.24432/C57604](https://doi.org/10.24432/C57604) |
| **Official URL** | https://archive.ics.uci.edu/dataset/331/sentiment+labelled+sentences |
| **License** | Creative Commons Attribution 4.0 (CC BY 4.0) |
| **Sources** | Amazon (product reviews), IMDb (movie reviews), Yelp (restaurant reviews) |
| **Format** | Tab-separated `.txt`: `review_text\tsentiment_label` |
| **Labels** | `0` = Negative sentiment, `1` = Positive sentiment |
| **Total Raw Records** | 3,000 (1,000 per source, perfectly balanced 500 Neg / 500 Pos each) |

### Dataset Files (place in `data/`)
- `data/amazon_cells_labelled.txt`
- `data/imdb_labelled.txt`
- `data/yelp_labelled.txt`

---

## Technologies & Libraries

| Component | Version |
|:---|:---|
| Python | 3.11 |
| pandas | ≥ 2.0, < 4 |
| numpy | ≥ 1.24, < 3 |
| scikit-learn | ≥ 1.4, < 2 |
| matplotlib | ≥ 3.7, < 4 |

---

## Project Folder Structure

```
Sentiment_Analysis_Comparative_Study/
├── main.py                         # Complete pipeline: load → preprocess → train → evaluate → predict
├── requirements.txt                # Python dependency specifications
├── README.md                       # This file
├── OUTPUT.md                       # Verified experimental outputs and analysis
├── Final_Sentiment_Analysis_Report.md  # Full academic report
├── VIVA_QUESTIONS.md               # 15 viva questions with answers
├── data/
│   ├── amazon_cells_labelled.txt   # Amazon product reviews (1,000 records)
│   ├── imdb_labelled.txt           # IMDb movie reviews (1,000 records)
│   └── yelp_labelled.txt           # Yelp restaurant reviews (1,000 records)
└── results/
    ├── model_comparison.csv        # Accuracy, Precision, Recall, F1 for all 4 models
    ├── model_comparison.png        # Grouped bar chart comparing all 4 classifiers
    ├── confusion_naive_bayes.png   # Confusion matrix — Naïve Bayes
    ├── confusion_decision_tree.png # Confusion matrix — Decision Tree
    ├── confusion_knn.png           # Confusion matrix — KNN
    ├── confusion_svm.png           # Confusion matrix — SVM
    ├── test_predictions.csv        # Per-review audit: text, actual label, all 4 predictions
    ├── what_if_svm_c.csv           # SVM C parameter sensitivity results
    ├── what_if_svm_c.png           # SVM C vs performance line graph (log scale)
    └── experiment_settings.json    # Full reproducibility configuration
```

---

## Installation & Execution

### 1 — Clone the Repository

```bash
git clone https://github.com/kishanbala123driod/Sentiment-analysis-ML.git
cd Sentiment-analysis-ML
```

### 2 — Create Virtual Environment

**Windows (PowerShell):**
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 3 — Place Dataset Files

Ensure the three `.txt` files are in `data/`. Download from:
> https://archive.ics.uci.edu/dataset/331/sentiment+labelled+sentences

### 4 — Run the Full Comparative Pipeline

```powershell
.\.venv\Scripts\python.exe main.py
```

This executes all 5 steps automatically:
1. Dataset loading and inspection
2. Preprocessing and deduplication
3. Stratified split + TF-IDF vectorization
4. Training and evaluation of all 4 classifiers
5. What-if SVM C experiment

---

## Model Descriptions

### 1. Naïve Bayes — `MultinomialNB(alpha=1.0)`
Probabilistic classifier based on Bayes' theorem. Assumes conditional independence between features. Laplace smoothing (α=1.0) prevents zero-probability issues for unseen n-grams. Despite the independence assumption, it is highly effective for TF-IDF text data and serves as the strongest baseline in this study.

### 2. Decision Tree — `DecisionTreeClassifier(max_depth=30, random_state=42)`
Builds a recursive binary tree by selecting features that maximize information gain (Gini impurity reduction). Limited to `max_depth=30` to control overfitting. Performs weakest among the four classifiers due to its inability to generalize well across three distinct review domains with high-dimensional sparse features.

### 3. K-Nearest Neighbours — `KNeighborsClassifier(n_neighbors=5, metric='cosine', algorithm='brute')`
Classifies a review by majority vote among its 5 nearest neighbors in TF-IDF space, using cosine similarity as the distance metric. Cosine similarity is preferred over Euclidean distance for text vectors as it is invariant to document length. Performance is constrained by the curse of dimensionality in the 3,000-feature space.

### 4. Support Vector Machine — `LinearSVC(C=1.0, random_state=42, max_iter=10000)`
Finds the maximum-margin linear hyperplane separating positive and negative sentiment feature vectors. `LinearSVC` is highly efficient for high-dimensional, sparse TF-IDF representations. Regularization parameter `C=1.0` provides the optimal balance between margin width and misclassification penalty, confirmed by the what-if experiment.

---

## Experimental Results

### Actual Held-Out Test Performance (595 test records)

| Rank | Model | Accuracy | Precision | Recall | F1-Score |
|:---:|:---|:---:|:---:|:---:|:---:|
| 🥇 1 | **Support Vector Machine** | **0.8101** | **0.8129** | **0.8047** | **0.8088** |
| 🥈 2 | Naïve Bayes | 0.7983 | 0.7980 | 0.7980 | 0.7980 |
| 🥉 3 | KNN | 0.7597 | 0.7533 | 0.7710 | 0.7621 |
| 4 | Decision Tree | 0.7092 | 0.7246 | 0.6734 | 0.6981 |

> Metrics computed with `pos_label=1` (Positive sentiment). Source: `results/model_comparison.csv`

---

## Model Comparison Chart

![Model Comparison Bar Chart](results/model_comparison.png)

*Grouped bar chart showing Accuracy, Precision, Recall and F1-Score for all four classifiers on the 595 held-out test records. Values annotated above each bar.*

---

## Confusion Matrices

Test set composition: **298 Negative (0), 297 Positive (1)**

### SVM (Best Model)
![SVM Confusion Matrix](results/confusion_svm.png)

| | Predicted Negative | Predicted Positive |
|:---|:---:|:---:|
| **Actual Negative** | 243 (TN) | 55 (FP) |
| **Actual Positive** | 58 (FN) | 239 (TP) |

### Naïve Bayes
![Naïve Bayes Confusion Matrix](results/confusion_naive_bayes.png)

| | Predicted Negative | Predicted Positive |
|:---|:---:|:---:|
| **Actual Negative** | 238 (TN) | 60 (FP) |
| **Actual Positive** | 60 (FN) | 237 (TP) |

### K-Nearest Neighbours
![KNN Confusion Matrix](results/confusion_knn.png)

| | Predicted Negative | Predicted Positive |
|:---|:---:|:---:|
| **Actual Negative** | 223 (TN) | 75 (FP) |
| **Actual Positive** | 68 (FN) | 229 (TP) |

### Decision Tree
![Decision Tree Confusion Matrix](results/confusion_decision_tree.png)

| | Predicted Negative | Predicted Positive |
|:---|:---:|:---:|
| **Actual Negative** | 222 (TN) | 76 (FP) |
| **Actual Positive** | 97 (FN) | 200 (TP) |

---

## What-If Experiment

Effect of SVM regularization parameter `C` on classification performance (fixed split and TF-IDF):

![SVM C What-If Graph](results/what_if_svm_c.png)

| C Value | Accuracy | Precision | Recall | F1-Score |
|:---:|:---:|:---:|:---:|:---:|
| 0.01 | 0.7647 | 0.7794 | 0.7374 | 0.7578 |
| 0.10 | 0.8000 | 0.8134 | 0.7778 | 0.7952 |
| **1.00** | **0.8101** | **0.8129** | **0.8047** | **0.8088** |
| 10.00 | 0.8050 | 0.8007 | 0.8114 | 0.8060 |
| 100.00 | 0.8017 | 0.7973 | 0.8081 | 0.8027 |

**Observation:** `C = 1.0` is the optimal regularization value — smaller C causes underfitting (lower recall); larger C causes marginal overfitting (lower precision).

> Source: `results/what_if_svm_c.csv`

---

## Real-Time Sentiment Prediction

### Interactive Terminal Mode

```powershell
.\.venv\Scripts\python.exe main.py --interactive
```

At the prompt, type any review sentence to get predictions from all four models simultaneously. Type `exit` to quit.

```
Enter review: The food was absolutely delicious and service was great
  - Naive Bayes    : Positive
  - Decision Tree  : Positive
  - KNN            : Positive
  - SVM            : Positive
```

### Single Sentence Prediction

```powershell
.\.venv\Scripts\python.exe main.py --predict "Absolutely loved the experience, will come back again"
```

```powershell
.\.venv\Scripts\python.exe main.py --predict "Completely disappointed. The product stopped working within two days"
```

---

## Reproducing Results

All results are 100% reproducible:

```powershell
# Full pipeline (produces all CSVs, PNGs, and terminal output)
.\.venv\Scripts\python.exe main.py

# Verify predictions interactively
.\.venv\Scripts\python.exe main.py --interactive
```

All randomness is fixed with `random_state=42`. The same results are obtained on every run.

---

## Key Design Decisions

| Decision | Justification |
|:---|:---|
| Stratified split | Preserves 50/50 class balance in both train and test partitions |
| TF-IDF on train only | Prevents vocabulary and IDF leakage from test documents |
| Apostrophes preserved | Retains polarity-critical contractions: `don't`, `wasn't`, `can't` |
| Deduplication before split | Prevents identical texts from appearing in both train and test |
| Cosine metric for KNN | Length-invariant similarity for variable-length review vectors |
| LinearSVC over kernel SVM | Efficient and well-suited for sparse, high-dimensional text data |

---

## Citation

If you use this dataset, cite:

> Kotzias, D., Denil, M., de Freitas, N., & Smyth, P. (2015). From group to individual labels using deep features. In *Proceedings of the 21st ACM SIGKDD International Conference on Knowledge Discovery and Data Mining* (pp. 597–606). ACM.

---

## Author

**Archana Sivakumar**  
SRM Institute of Science and Technology  
October 2026
